package jacs;

import java.util.Scanner;

import jacs.gui.Gui;

/**
 * This class Main for Running Server for eXceedVote.
 * @author GoDParTicle
<<<<<<< HEAD
 * @author nookskill
=======
 * @author Nookskill
>>>>>>> guitest
 */

public class Main {
	public static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {

		Gui gui = new Gui();
		gui.run();
		
		
	}
}
