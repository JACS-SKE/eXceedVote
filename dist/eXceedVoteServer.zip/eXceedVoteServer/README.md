eXceedVoteServer
================

This Project is server for eXceedVote Project, 
it have classes for server and classes for connect to database.