package jacs.constant;

public class Constant {
	
	public final static String AUTH_PANEL = "Login";
	public final static String CRI_PANEL = "Select criteria and a project!";
	public final static String POINT_PANEL = "Give your point to each team";
	
}
